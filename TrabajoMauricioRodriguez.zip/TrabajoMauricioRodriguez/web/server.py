from flask import Flask,render_template, request, session, Response, redirect
from database import connector
from model import entities
import json

db = connector.Manager()
engine = db.createEngine()
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/Users')
def users():
    db_session = db.getSession(engine)
    users = db_session.query(entities.User)
    data = users[:]
    return Response(json.dumps(data, cls=connector.AlchemyEncoder), mimetype = 'application/json')

@app.route('/Users/<id>', methods = ['GET'])
def get_User(id):
    db_session = db.getSession(engine)
    users = db_session.query(entities.User).filter(entities.User.id == id)
    for user in users:
        js= json.dumps(user, cls=connector.AlchemyEncoder)
        return Response(js,status=200,mimetype='application/json')

    message={"status":404,"messaege":"Not Found"}
    return Response(message, status = 404,mimetype='application/json')

@app.route('/create_Users')
def create_users():
    db_session = db.getSession(engine)
    user= entities.User(id=1,Codigo= 201910234,Nombre='Pepe',Apellido='Pascual',Password= 'Utec5452')
    db_session.add(user)
    db_session.commit()
    return "test user created"


if __name__ == '__main__':
    app.secret_key = ".."
    app.run(port=8080, threaded = True, host=('0.0.0.0'))
