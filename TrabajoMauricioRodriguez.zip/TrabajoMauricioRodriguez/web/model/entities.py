from sqlalchemy import Column, Integer, String, Sequence, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from database import connector

class User(connector.Manager.Base):
    __tablename__ = 'Users'
    id = Column(Integer, Sequence('Users_id_seq'), primary_key=True)
    Codigo = Column(Integer)
    Nombre = Column(String(50))
    Apellido = Column(String(20))
    Password = Column(String(20))

class Message(connector.Manager.Base):
    __tablename__= 'messages'
    id = Column(Integer,Sequence('message_id_seq'), primary_key= True)
    content = Column(String(500))
    sent_on = Column(DateTime(timezone= True))
    user_from_id = Column(Integer, ForeignKey('Users.id'))
    user_to_id = Column(Integer, ForeignKey('Users.id'))
    user_from = relationship(User,foreign_keys = [user_from_id])
    user_to= relationship(User,foreign_keys= [user_to_id])